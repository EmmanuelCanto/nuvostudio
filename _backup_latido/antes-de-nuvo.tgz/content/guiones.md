# Guiones para las voces de la página

Todos los guiones están pensados para generarse con IA (ElevenLabs u otra) en **dos voces: hombre y mujer**, en español neutro de México, ritmo tranquilo pero con energía (como un reel). Genera cada guion en MP3, 44.1 kHz, y guárdalo con el nombre indicado dentro de `public/audio/voz/`.

Después corre `python3 scripts/align.py` para que la página sepa en qué segundo cae cada palabra (ver `scripts/README.md`). Las palabras marcadas con `*asteriscos*` son las **palabras clave**: en pantalla salen grandes y en serif cursiva, igual que en tus videos.

---

## 1. Edición de video — "Así editamos tus videos"

Es el que suena en la sección **Edición de video**, sobre el celular animado. Dura unos 20 segundos. El visitante elige si lo escucha con voz de hombre o de mujer, y los subtítulos van palabra por palabra sincronizados con el audio.

**Archivos:** `edicion-hombre.mp3` y `edicion-mujer.mp3`

> Así editamos tus videos para que *nadie* deje de verlos.
> Cortamos los silencios, ponemos subtítulos *palabra por palabra*,
> y animamos lo que dices con *motion graphics*.
> Música, efectos y formato vertical, listos para *TikTok*, *Reels* y *Shorts*.
> Tú grabas con tu celular. Nosotros hacemos el *resto*.

**Indicaciones para la voz:** pausa corta después de "verlos" y después de "graphics". Énfasis natural en "nadie", "palabra por palabra" y "resto". Sin exagerar: suena como alguien que explica, no como un comercial.

---

## 2. Voces que regresan — demo de clonación

En la sección **Voces que regresan** la animación muestra el proceso real con dos audios:

### 2a. Audio de entrada (voz original de una señora adulta)

**Archivo:** `voz-entrada-original.mp3` (de 20 a 60 segundos de una grabación real, limpia, con permiso de la persona)

Si vas a grabar a una señora para la demo, pídele que lea algo natural y cálido, por ejemplo:

> Hola, mi amor. Ya es tarde y todavía no me has llamado.
> Acuérdate de comer bien y de abrigarte, que está haciendo frío.
> Mañana te preparo el caldo que te gusta. Te quiero mucho, cuídate.

Nota: para que la clonación salga clara se necesita audio sin música ni ruido de fondo, con la persona cerca del micrófono. Y el consentimiento por escrito de la señora, aunque sea para una demo.

### 2b. Texto que escribe la familia (lo que se "teclea" en la pantalla)

Este es el texto que aparece escribiéndose en el paso 02 y que luego se escucha en el paso 04 con la voz clonada:

**Archivo del resultado:** `voz-salida-clonada.mp3`

> Feliz cumpleaños, mi niña. Aunque ya no esté a tu lado, siempre estoy contigo.
> Estoy muy orgullosa de ti. Te quiero mucho.

**Indicaciones:** generar con la voz clonada a partir de `voz-entrada-original.mp3`, velocidad normal, estabilidad alta para que suene clara. Después del paso 04 la página muestra la frase sincronizada palabra por palabra mientras suena.

---

## 3. Motion graphics (opcional, sección "Videos que se entienden en segundos")

**Archivos:** `motion-hombre.mp3` y `motion-mujer.mp3` (unos 10 segundos)

> Tu idea, en *movimiento*.
> Un guion, una animación, y un video que se entiende en *segundos*.

---

## 4. Sitios web (opcional)

**Archivos:** `web-hombre.mp3` y `web-mujer.mp3`

> Una página que carga *rápido*, se ve bien en el celular
> y lleva a tus clientes directo a tu *WhatsApp*.

---

## 5. Marketing y NFC (opcional)

**Archivos:** `marketing-hombre.mp3` y `marketing-mujer.mp3`

> Tu cliente acerca su celular, deja su *reseña*,
> y tu negocio sube en *Google Maps*.

---

## Resumen de archivos esperados en `public/audio/voz/`

| Archivo | Obligatorio | Para qué |
| --- | --- | --- |
| `edicion-hombre.mp3` | Sí | Sección Edición, voz de hombre |
| `edicion-mujer.mp3` | Sí | Sección Edición, voz de mujer |
| `voz-entrada-original.mp3` | Sí | Paso 01 de Voces (audio original) |
| `voz-salida-clonada.mp3` | Sí | Paso 04 de Voces (voz clonada) |
| `motion-*.mp3`, `web-*.mp3`, `marketing-*.mp3` | No | Locuciones opcionales |

Mientras no existan los archivos, la página usa la animación muda que ya tiene. En cuanto los agregues y corras `align.py`, aparece el botón de "Escuchar" con la elección de voz.
