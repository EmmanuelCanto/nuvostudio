import { useEffect, useRef } from 'react';
import engine, { peakOf } from '../audio/engine.js';
import { reduceMotion } from './anim.js';

/*
  Port del "motor de escenas" original como hook.
    useScene(ref, { duration, finalT, loop, init, cues })
      init(el, ctl) -> render(t)   (se ejecuta una vez; puede devolver null para desactivar)
      cues: [{t, sfx, ...}] o función () => cues (evaluada tras init, por si dependen de él)
  - Empieza al entrar en pantalla (IntersectionObserver, umbral .18) y se detiene al salir.
  - Con prefers-reduced-motion dibuja el estado final (finalT) y no anima.
  - Cada cue suena una sola vez por ciclo, en (t − pico del archivo).
  Devuelve un ref con controles: { render, stop, suspend, release, pause, resume, isOn }.
*/
export function useScene(ref, opts) {
  const ctl = useRef({ render: () => {}, stop() {}, suspend() {}, release() {}, pause() {}, resume() {}, isOn: () => false });
  const optsRef = useRef(opts);
  optsRef.current = opts;

  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    const o = optsRef.current;
    const reduce = reduceMotion();
    let render = null;
    try { render = o.init(el, ctl.current); } catch (e) { console.error('scene init', e); render = null; }
    if (!render) return undefined;
    const D = o.duration, fin = o.finalT == null ? D : o.finalT, loop = !!o.loop;
    let cues = typeof o.cues === 'function' ? o.cues() : (o.cues || []);
    // cue -> { start, offset }: el archivo arranca en (t − pico); si es negativo, empieza avanzado.
    cues = cues.map((c) => {
      const peak = peakOf(c.sfx);
      const start = Math.max(0, c.t - peak);
      return { ...c, start, offset: peak - (c.t - start) };
    });

    try { render(fin); } catch (e) { /* noop */ }

    let on = false, done = false, suspended = false, paused = false, visible = false;
    let t0 = 0, raf = 0, last = -1, pausedAt = 0, wasOn = false;

    function fire(a, b) {
      // dispara los cues con start en (a, b]
      if (!engine.enabled || !cues.length) return;
      cues.forEach((c) => { if (c.start > a && c.start <= b) engine.playSfx(c.sfx, c); });
    }
    function tick(now) {
      raf = 0;
      if (!on) return;
      let t = (now - t0) / 1000;
      let more = true;
      if (loop) {
        const cyc = t % D;
        if (cyc < last) { fire(last, D + 1); fire(-1, cyc); } else fire(last, cyc);
        t = cyc;
      } else if (t >= D) { fire(last, D + 1); t = D; on = false; more = false; }
      else fire(last, t);
      last = t;
      try { render(t); } catch (e) { /* noop */ }
      if (more) raf = requestAnimationFrame(tick);
    }
    function start() {
      if (reduce) { try { render(fin); } catch (e) { /* noop */ } return; }
      on = true; t0 = performance.now(); last = -1; paused = false;
      if (!raf) raf = requestAnimationFrame(tick);
    }
    function stop() { on = false; if (raf) { cancelAnimationFrame(raf); raf = 0; } }

    Object.assign(ctl.current, {
      render: (t) => { try { render(t); } catch (e) { /* noop */ } },
      isOn: () => on,
      stop,
      // Suspender: detiene el bucle y evita que el observador lo reinicie (modo voz).
      suspend() { suspended = true; stop(); },
      release() { suspended = false; if (visible && !on && !done) { if (!loop) done = true; start(); } },
      // Pausar/reanudar congela el reloj donde está.
      pause() {
        if (paused) return;
        paused = true; wasOn = on; suspended = true; pausedAt = performance.now(); stop();
      },
      resume() {
        if (!paused) return;
        paused = false; suspended = false;
        if (!visible) return;
        if (wasOn) { on = true; t0 += performance.now() - pausedAt; if (!raf) raf = requestAnimationFrame(tick); }
        else if (!done) { if (!loop) done = true; start(); }
      },
    });

    let io = null;
    if ('IntersectionObserver' in window && !reduce) {
      io = new IntersectionObserver((es) => {
        es.forEach((en) => {
          visible = en.isIntersecting;
          if (suspended) return;
          if (en.isIntersecting) { if (!on && !done && !paused) { if (!loop) done = true; start(); } }
          else if (loop) { stop(); paused = false; }
        });
      }, { threshold: .18 });
      io.observe(el);
    }
    return () => { stop(); if (io) io.disconnect(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return ctl;
}
