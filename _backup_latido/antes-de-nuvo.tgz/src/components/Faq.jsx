import { faq } from '../data/site.js';

export default function Faq() {
  return (
    <section className="sec light" id="faq">
      <div className="wrap">
        <div className="meta"><span>Latido <span className="it">preguntas</span> frecuentes</span><span>2026 / 12</span></div>
        <div className="faq-grid">
          <h2>Lo que más nos <em>preguntan</em>.</h2>
          <div className="faq">
            {faq.map((f) => (
              <details key={f.q}>
                <summary>{f.q}</summary>
                <p>{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
