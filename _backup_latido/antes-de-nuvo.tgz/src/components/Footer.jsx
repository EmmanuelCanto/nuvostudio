import { contact } from '../data/site.js';
export default function Footer() {
  return (
    <footer>
      <div className="wrap">
        <span>© {contact.year} Latido Studio. Contenido digital con corazón. Hecho en México.</span>
        <span><a href="#politica-etica">Política ética de voz</a> / <a href="#contacto">Contacto</a></span>
      </div>
    </footer>
  );
}
