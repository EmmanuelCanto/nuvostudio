import { founders } from '../data/site.js';

export default function Nosotros() {
  return (
    <section className="sec tint" id="nosotros">
      <div className="wrap">
        <div className="meta"><span>Latido <span className="it">quiénes</span> somos</span><span>2026 / 11</span></div>
        <div className="head">
          <h2>Dos personas, <em>un mismo latido</em>.</h2>
          <p>Latido Studio nació de una pareja que comparte el gusto por contar historias con tecnología. Conoce a cada quien y revisa su trayectoria.</p>
        </div>
        <div className="founders">
          {founders.map((f) => (
            <a className="founder" href={'#' + f.id} key={f.id}>
              <div><span className="ini">{f.ini}</span><h3>{f.name}</h3><p className="role">{f.role}</p></div>
              <span className="go">Ver perfil y CV</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
