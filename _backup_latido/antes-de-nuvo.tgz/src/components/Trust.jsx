export default function Trust() {
  return (
    <div className="trust light">
      <div className="wrap">
        <p>Contenido listo para publicar en</p>
        <ul><li>Instagram</li><li>TikTok</li><li>Facebook</li><li>Google Maps</li><li>WhatsApp</li><li>tu sucursal</li></ul>
      </div>
    </div>
  );
}
