/*
  Mapa de efectos de sonido por escena (ver content/sfx-map.md y guia-efectos-de-sonido.md).
  Regla general: sonido = acción visual.

  PEAK: segundo del pico dentro de cada archivo de public/audio/sfx/.
  El motor dispara el audio en (t − peak) para que el pico caiga sobre la acción.
  Si (t − peak) < 0 el archivo arranca ya avanzado (offset) al inicio del ciclo.

  Cada cue: { t, sfx, loopFor?, fade?, gain? }
    t        segundo del ciclo de la escena en que ocurre la acción
    loopFor  repetir el archivo en bucle durante N segundos (typing)
    fade     segundos de desvanecimiento al final
*/
export const PEAK = {
  'projector-draw': 3.34,
  'camera-flash': 0.02,
  shutter: 0.05,
  'click-1': 1.66, 'click-2': 0.1, 'click-3': 0.05,
  'ui-click-soft': 0.05,
  'ui-cli': 0.05,
  'ui-aparicion-1': 0.05, 'ui-aparicion-2': 0.05, 'ui-aparicion-3': 0.05, 'ui-aparicion-4': 0.05,
  burbuja: 0.05,
  'ui-down': 0.05,
  'beep-gleam': 0.1,
  coins: 0.15,
  'riser-reverse': 0.93,
  woosh: 0.5, 'woosh-2': 0.58, 'woosh-rapido': 0.46, 'woosh-fast': 0.43, 'woosh-bomb': 0.14,
  typing: 0,
  glitch: 0.05, 'glitch-ligero': 0.05,
  'pop-1': 0.05, 'pop-2': 0.05, 'pop-3': 0.05,
  'spin-beep': 0.8,
};

export const SFX_NAMES = Object.keys(PEAK);

export const MUSIC = { src: '/audio/music/fondo-inspiring.mp3', gain: 0.18, duck: 0.08, fadeIn: 1.5 };

// Las escenas calculan algunos instantes (pastillas, keyframes) al iniciarse;
// por eso varias tablas son funciones que reciben esos tiempos.

// Hero (10.5 s)
export function heroCues(pillTimes) {
  const pillSfx = ['ui-aparicion-1', 'burbuja', 'ui-cli', 'ui-aparicion-3'];
  const cues = [
    { t: 0, sfx: 'click-3' },
    { t: 0.4, sfx: 'projector-draw', fade: 1.2 },
    { t: 9.3, sfx: 'ui-down' },
  ];
  pillTimes.forEach((t, i) => {
    cues.push({ t, sfx: pillSfx[i % pillSfx.length] });
    cues.push({ t: t - 0.1, sfx: 'click-2' }); // keyframe sobre la curva
  });
  return cues;
}

// Motion / editor (9 s)
export function motionCues(keyframeTimes) {
  const cues = [
    { t: 0.1, sfx: 'ui-cli' },
    { t: 0.5, sfx: 'riser-reverse' },
    { t: 1.3, sfx: 'woosh-fast' },
    { t: 3.5, sfx: 'click-3' }, { t: 3.67, sfx: 'click-3' }, { t: 3.84, sfx: 'click-3' }, { t: 4.01, sfx: 'click-3' },
    { t: 4.6, sfx: 'beep-gleam' },
  ];
  keyframeTimes.forEach((t) => cues.push({ t, sfx: 'click-2', gain: 0.7 }));
  return cues;
}

// Edición sin voz (9 s): cortes, una palabra cada 0.84 s (10 palabras en 8.4 s)
export function editCues(wordTimes) {
  const cues = [
    { t: 2.8, sfx: 'shutter' }, { t: 2.8, sfx: 'glitch-ligero' },
    { t: 5.6, sfx: 'shutter' }, { t: 5.6, sfx: 'glitch-ligero' },
    { t: 0.9, sfx: 'projector-draw', fade: 1 },
    { t: 1.2, sfx: 'coins' },
    { t: 3.8, sfx: 'coins' },
  ];
  wordTimes.forEach((t, i) => cues.push({ t, sfx: i % 2 ? 'click-2' : 'click-3' }));
  return cues;
}

// Voces (13.5 s)
export const vocesCues = [
  { t: 0.2, sfx: 'ui-aparicion-2' },
  { t: 0.5, sfx: 'riser-reverse' },
  { t: 2.5, sfx: 'ui-aparicion-4' },
  { t: 2.8, sfx: 'typing', loopFor: 3, fade: 0.3 },
  { t: 6.0, sfx: 'projector-draw', fade: 1 },
  { t: 6.9, sfx: 'beep-gleam' },
  { t: 8.2, sfx: 'woosh' },
  { t: 8.9, sfx: 'ui-aparicion-1' },
  { t: 9.3, sfx: 'ui-click-soft' },
];

// Web (11 s)
export function webCues(blockTimes) {
  const cues = [
    { t: 0.2, sfx: 'projector-draw', fade: 1.5 },
    { t: 5.9, sfx: 'ui-click-soft' },
    { t: 6.4, sfx: 'woosh-fast' },
    { t: 7.3, sfx: 'coins' },
    { t: 8.8, sfx: 'beep-gleam' },
  ];
  blockTimes.forEach((t, i) => cues.push({ t, sfx: i % 2 ? 'click-2' : 'click-1', gain: 0.6 }));
  return cues;
}

// Marketing (13 s)
export function mktCues(pillTimes) {
  const pillSfx = ['burbuja', 'ui-cli', 'ui-aparicion-1'];
  const cues = [
    { t: 0.3, sfx: 'woosh-2' },
    { t: 1.5, sfx: 'spin-beep' },
    { t: 2.1, sfx: 'ui-aparicion-3' },
    { t: 3.3, sfx: 'pop-1' }, { t: 3.58, sfx: 'pop-2' }, { t: 3.86, sfx: 'pop-3' }, { t: 4.14, sfx: 'pop-1' }, { t: 4.42, sfx: 'pop-2' },
    { t: 3.3, sfx: 'coins' },
    { t: 5.2, sfx: 'projector-draw', fade: 1.2 },
    { t: 6.4, sfx: 'coins' },
  ];
  pillTimes.forEach((t, i) => cues.push({ t, sfx: pillSfx[i % pillSfx.length] }));
  return cues;
}

// Perfiles (3.4 s)
export function cvCues(nodeTimes) {
  const cues = [{ t: 0.2, sfx: 'projector-draw', fade: 1 }];
  nodeTimes.forEach((t) => {
    cues.push({ t, sfx: 'click-2' });
    cues.push({ t: t + 0.15, sfx: 'ui-cli', gain: 0.7 });
  });
  return cues;
}
