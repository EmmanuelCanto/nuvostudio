# Guiones para las voces de nüvo

Guarda cada audio terminado en `public/audio/voz/` con el **nombre exacto** que se indica. En cuanto estén ahí (y sus `.json` de tiempos, ver el final), la página muestra sola los botones para escuchar. Mientras no existan, las secciones siguen con su animación muda.

Las palabras entre `*asteriscos*` son **palabras clave**: en el subtítulo salen grandes en cursiva y cada una suena con un efecto distinto, sin repetirse. **No escribas los asteriscos en el generador de voz**, solo aquí.

---

## 1. Edición de video — "Así editamos tus videos"

Suena en la sección **Edición de video**, sobre el celular animado. El visitante elige **Hombre** o **Mujer** y los subtítulos aparecen palabra por palabra, sincronizados con el audio. Dura unos 18 a 22 segundos.

**Archivos:** `edicion-hombre.mp3` y `edicion-mujer.mp3` (el mismo guion con las dos voces)

> Así editamos tus videos para que *nadie* deje de verlos.
> Quitamos silencios y muletillas, ponemos subtítulos *palabra por palabra*
> y animamos lo que dices con *motion graphics*.
> Música, efectos y formato vertical, listo para *TikTok*, *Reels* y *Shorts*.
> Tú grabas con tu celular. En *nüvo* hacemos el resto.

**Texto para pegar en el generador** (sin asteriscos; "nüvo" escrito como quieres que se pronuncie):

```
Así editamos tus videos para que nadie deje de verlos. Quitamos silencios y muletillas, ponemos subtítulos palabra por palabra y animamos lo que dices con motion graphics. Música, efectos y formato vertical, listo para TikTok, Reels y Shorts. Tú grabas con tu celular. En nuvo hacemos el resto.
```

**Dirección de voz:** cercana y con energía, como alguien que te explica algo en un reel, no como comercial de radio. Pausa corta después de "verlos" y después de "graphics". "TikTok, Reels y Shorts" un poco más rápido, como lista.

**Sugerencia de ajustes (ElevenLabs):** modelo *Multilingual v2* (o el más reciente en español), voz en español de México de la *Voice Library*, estabilidad 45–55 %, similitud 75 %, estilo 10–20 %, velocidad 1.0. Exporta MP3 44.1 kHz. Usa voces del mismo "tono" para hombre y mujer, para que se sientan de la misma marca.

---

## 2. Voces que regresan — demo de clonación

La animación muestra cuatro pasos. Para la demo real se necesitan **dos audios**: el "antes" (la voz original de una señora adulta, tal como la conservaría una familia) y el "después" (la voz clonada diciendo un mensaje nuevo, clara).

**Antes de grabar:** pídele a la señora su **consentimiento por escrito** para clonar su voz y usarla como demostración en la página. La página ya aclara que es una recreación con IA.

### 2a. Audio de entrada (voz original de una señora adulta)

**Archivo para la página:** `voz-entrada-original.mp3`, de **15 a 25 segundos**. Es lo que se escucha en el paso 01. Puede sonar como una nota de voz casera (un poco de ambiente está bien: así se nota la diferencia con el resultado).

**Para clonar la voz** necesitas otra grabación más larga y más limpia, de **1 a 3 minutos**, que no se publica. Pídele que lea con calma, como si le hablara a alguien de su familia, en un cuarto sin eco ni ruido, con el celular a unos 20 cm de la boca:

> Hola, mi amor. Ya es tarde y todavía no me has llamado.
> Acuérdate de comer bien y de abrigarte, que está haciendo frío.
> Mañana te preparo el caldo que te gusta, con su arroz y su limón.
> El domingo vienen tus tíos, a ver si te das una vuelta.
> Fíjate que el rosal del patio ya echó flores otra vez, ¡y bien bonitas!
> Yo aquí sigo, con mis novelas y mi cafecito de la tarde.
> Cuídate mucho, mijo. Te mando un abrazo muy fuerte y mi bendición.

Si quieres más material para que el clon salga mejor, pídele que además platique libremente un minuto: cómo era su casa de niña, una receta, un consejo. Lo natural clona mejor que lo leído.

Para la página, recorta de 15 a 25 segundos de esa lectura (por ejemplo, las tres primeras frases) y guárdalos como `voz-entrada-original.mp3`.

### 2b. Mensaje con la voz clonada (resultado)

Este es el texto que se "teclea" en el paso 02 y que se escucha en el paso 04 con la voz clonada, con subtítulos sincronizados. **Debe coincidir** con `voices.voces.texto` en `src/data/site.js` (si lo cambias aquí, cámbialo allá).

**Archivo del resultado:** `voz-salida-clonada.mp3`

> Feliz cumpleaños, mi niña. Aunque ya no esté a tu lado, *siempre* estoy contigo.

**Cómo generarlo, paso a paso:**
1. Limpia la grabación larga (2a) con un aislador de voz (ElevenLabs *Voice Isolator*, Adobe *Enhance Speech* o similar) para quitar ruido y eco.
2. Crea el clon (ElevenLabs *Instant Voice Cloning* o *Professional Voice Cloning*) con ese audio limpio. Confirma que tienes el permiso de la persona: la plataforma lo pide.
3. Genera el texto de arriba con el clon: estabilidad alta (60–70 %), similitud 80–90 %, estilo bajo (0–10 %), velocidad 0.95. Así suena clara y serena.
4. Escucha varias tomas y quédate con la más natural. Exporta MP3 44.1 kHz.

**Dirección de voz:** cálida, despacio, con una pausa después de "niña" y otra antes de "siempre".

---

## 3. Motion graphics (opcional)

**Archivos:** `motion-hombre.mp3` y `motion-mujer.mp3` (unos 10 segundos)

> Tu idea, en *movimiento*.
> Un guion, una animación, y un video que se entiende en *segundos*.

---

## 4. Sitios web (opcional)

**Archivos:** `web-hombre.mp3` y `web-mujer.mp3`

> Una página que carga *rápido*, se ve bien en el celular
> y lleva a tus clientes directo a tu *WhatsApp*.

---

## 5. Marketing y NFC (opcional)

**Archivos:** `marketing-hombre.mp3` y `marketing-mujer.mp3`

> Tu cliente acerca su celular, deja su *reseña*,
> y tu negocio sube en *Google Maps*.

---

## Resumen de archivos en `public/audio/voz/`

| Archivo | Obligatorio | Para qué |
| --- | --- | --- |
| `edicion-hombre.mp3` | Sí | Edición de video, voz de hombre |
| `edicion-mujer.mp3` | Sí | Edición de video, voz de mujer |
| `voz-entrada-original.mp3` | Sí | Voces, paso 01 (voz original, 15–25 s) |
| `voz-salida-clonada.mp3` | Sí | Voces, paso 04 (voz clonada, clara) |
| `motion-*`, `web-*`, `marketing-*` | No | Locuciones opcionales (aún sin usar en la página) |

## Sincronizar los subtítulos

No se puede hacer en tiempo real: se calcula una vez por audio y queda guardado en un `.json` junto al MP3 (en qué segundo empieza y termina cada palabra). Dos opciones:

- **Mándale los MP3 a Claude** y él genera los `.json`.
- **O hazlo tú en tu Mac:** `python3 scripts/align.py` (ver `scripts/README.md`).

Si alguna palabra queda desfasada, se corrige a mano en el `.json` (son segundos). También puedes fijar el efecto de una palabra con `"sfx": "nombre-del-efecto"`, o silenciarla con `"sfx": ""`.
