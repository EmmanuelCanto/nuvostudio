/*
  Logotipo nüvo en texto vivo (tipografía Tenor Sans).
  El diamante y el círculo sobre la "u" forman la diéresis.
  Escala con el font-size del contenedor: <Nuvo /> dentro de cualquier texto.
*/
export default function Nuvo({ className = '' }) {
  return (
    <span className={('nuvo ' + className).trim()} role="img" aria-label="nüvo">
      <span aria-hidden="true">n<span className="nuvo-u">u<i className="nuvo-dia" /><i className="nuvo-dot" /></span><span className="nuvo-v">v</span>o</span>
    </span>
  );
}
