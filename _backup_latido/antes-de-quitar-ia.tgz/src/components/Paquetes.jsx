import { packages } from '../data/site.js';
import Nuvo from './Nuvo.jsx';

export default function Paquetes() {
  return (
    <section className="sec light" id="paquetes">
      <div className="wrap">
        <div className="meta"><span><Nuvo /> <span className="it">paquetes</span> de contenido</span><span>2026 / 05</span></div>
        <div className="head">
          <h2>Paquetes de edición y <em>creación de contenido</em>.</h2>
          <p>Antes de editar, analizamos tu negocio o tu marca personal: a quién le hablas, qué publica tu competencia y qué videos te conviene hacer. Con eso planeamos cada video.</p>
        </div>
        <ol className="plan-flow" aria-label="Cómo planeamos tu contenido">
          <li><b>Analizamos</b><span>Tu negocio, tu público y tu competencia.</span></li>
          <li><b>Planeamos</b><span>Calendario de temas y ganchos del mes.</span></li>
          <li><b>Escribimos</b><span>Guiones cortos listos para grabar.</span></li>
          <li><b>Editamos</b><span>Cortes, subtítulos, motion y música.</span></li>
          <li><b>Medimos</b><span>Revisamos qué funcionó y ajustamos.</span></li>
        </ol>
        <div className="prices pk">
          {packages.map((p) => (
            <div className={'price' + (p.hl ? ' hl' : '')} key={p.title}>
              {p.flag && <span className="flag">{p.flag}</span>}
              <h3>{p.title}</h3>
              <p className="who">{p.who}</p>
              <span className="from">Desde</span>
              <div className="amt">{p.amount} <small>MXN</small></div>
              <p className="per">{p.per}</p>
              <ul>{p.items.map((it) => <li key={it}>{it}</li>)}</ul>
              <a className={'btn ' + (p.hl ? 'btn-w' : 'btn-ok')} href="#contacto">{p.cta}</a>
            </div>
          ))}
        </div>
        <p className="note"><b>Precios de referencia.</b> Cada plan se ajusta a tu negocio después de una llamada sin costo. Videos de más de 60 s, grabación presencial o producción con IA (voces, clips generados) se cotizan aparte.</p>
      </div>
    </section>
  );
}
