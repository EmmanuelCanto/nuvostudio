import { useEffect, useRef, useState } from 'react';
import { videos, videoTabs } from '../data/site.js';
import { qa, reduceMotion } from '../scenes/anim.js';
import Nuvo from './Nuvo.jsx';

/* Galería: lista en src/data/site.js. src vacío = recuadro de relleno; con src = video
   (autoplay sin sonido al entrar en pantalla; clic = alternar sonido, uno a la vez). */
export default function VideosGallery() {
  const root = useRef(null);
  const [f, setF] = useState('all');

  useEffect(() => {
    const el = root.current, reduce = reduceMotion();
    const cleanups = [];
    qa(el, '.vid-m').forEach((m) => {
      const v = m.querySelector('video'), snd = m.querySelector('.snd');
      if (!v) return;
      if ('IntersectionObserver' in window && !reduce) {
        const io = new IntersectionObserver((es) => {
          es.forEach((en) => {
            if (en.isIntersecting) { const pr = v.play(); if (pr && pr.then) pr.then(() => { m.classList.add('playing'); }).catch(() => {}); }
            else { v.pause(); m.classList.remove('playing'); }
          });
        }, { threshold: .5 });
        io.observe(m);
        cleanups.push(() => io.disconnect());
      }
      function toggle() {
        qa(el, '.vid-m video').forEach((o) => { if (o !== v) { o.muted = true; const s2 = o.parentNode.querySelector('.snd'); if (s2) s2.textContent = 'Sin sonido'; } });
        v.muted = !v.muted;
        snd.textContent = v.muted ? 'Sin sonido' : 'Con sonido';
        const pr = v.play(); if (pr && pr.catch) pr.catch(() => {});
        m.classList.add('playing');
      }
      const key = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } };
      m.addEventListener('click', toggle);
      m.addEventListener('keydown', key);
      cleanups.push(() => { m.removeEventListener('click', toggle); m.removeEventListener('keydown', key); });
    });
    return () => cleanups.forEach((c) => c());
  }, []);

  const catLabel = (cat) => (videoTabs.find((t) => t.f === cat) || {}).label || cat;
  return (
    <section className="sec dark" id="portafolio" style={{ '--gx': '50%', '--gy': '30%' }}>
      <div className="wrap">
        <div className="meta"><span><Nuvo /> <span className="it">trabajos</span> seleccionados</span><span>2026 / 04</span></div>
        <div className="head">
          <h2>Videos editados <em>con IA</em>.</h2>
          <p>Desde piezas de puro motion graphics hasta los videos de Polígonos del Evangelio y videos hablando a cámara con motion graphics encima.</p>
        </div>
        <div className="tabs" role="group" aria-label="Filtrar videos">
          {videoTabs.map((t) => <button type="button" key={t.f} data-f={t.f} aria-pressed={f === t.f ? 'true' : 'false'} onClick={() => setF(t.f)}>{t.label}</button>)}
        </div>
        <div className="vids" id="vids" ref={root}>
          {videos.map((v, i) => (
            <figure className="vid" data-cat={v.cat} key={i} hidden={!(f === 'all' || v.cat === f)}>
              <div className={'vid-m' + (v.src ? ' has' : '')} data-src={v.src} tabIndex={0} role="button" aria-label={'Reproducir: ' + v.title}>
                {v.src && <video src={v.src} muted loop playsInline preload="metadata" />}
                <div className="ph" style={v.src ? { display: 'none' } : undefined}><svg viewBox="0 0 90 160" aria-hidden="true"><path d="M10 120 C 40 118, 50 50, 80 42" fill="none" stroke="#4D8BFF" strokeWidth="1.4" /><rect x="-2.5" y="-2.5" width="5" height="5" transform="translate(10 120) rotate(45)" fill="#fff" /><rect x="-2.5" y="-2.5" width="5" height="5" transform="translate(80 42) rotate(45)" fill="#fff" /></svg><span>[Sube aquí tu video]</span></div>
                <span className="cat">{catLabel(v.cat)}</span>
                <span className="play"><svg viewBox="0 0 16 16"><path d="M3 1.500l11 6.500-11 6.500z" fill="#0B0B14" /></svg></span>
                <span className="snd">Sin sonido</span>
              </div>
              <figcaption><b>{v.title}</b><span>{v.sub}</span></figcaption>
            </figure>
          ))}
        </div>
        <p className="vid-note">Toca un video para verlo con sonido. ¿Quieres uno así para tu marca? <a href="#contacto">Escríbenos</a>.</p>
      </div>
    </section>
  );
}
