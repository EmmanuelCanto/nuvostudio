/*
  ============================================================
  NÜVO — GUÍA RÁPIDA PARA EDITAR
  Este es el ÚNICO archivo que necesitan tocar para cambiar
  textos de relleno, precios, preguntas, perfiles y videos.
  Busca (Ctrl+F) el carácter "[" para encontrar todos los
  textos de relleno que deben reemplazar:
    [Tu nombre], [Nombre de tu novia], [WhatsApp],
    [correo@agencia.com], [Ciudad], [Año], [Empresa o cliente], etc.
  Los enlaces de WhatsApp usan https://wa.me/520000000000
  (reemplacen 520000000000 por 52 + su número a 10 dígitos).
  Las escenas animadas marcadas "Ejemplo ilustrativo" no son
  resultados reales: cámbienlas cuando tengan datos propios.

  Archivos:
    Videos  -> carpeta public/videos/   (y escribe el nombre en `videos` abajo)
    CV PDF  -> carpeta public/cv/       (y escribe la ruta en `cvUrl` de cada fundador)
    Voces   -> carpeta public/audio/voz/ (ver content/guiones.md y scripts/README.md)
  ============================================================
*/

// Reemplaza 520000000000 por 52 + tu número a 10 dígitos
export const whatsappNumber = '520000000000';
export const whatsappUrl = 'https://wa.me/' + whatsappNumber;

export const contact = {
  whatsappLabel: '[WhatsApp]',          // texto que se muestra (ej. "+52 55 1234 5678")
  email: 'correo@agencia.com',          // correo real (para el enlace mailto:)
  emailLabel: '[correo@agencia.com]',   // texto que se muestra
  city: '[Ciudad]',
  year: '[Año]',                        // pie de página: © [Año] nüvo
};

export const titles = {
  home: 'nüvo — Agencia de contenido digital',
  'perfil-1': 'Perfil 1 · nüvo',
  'perfil-2': 'Perfil 2 · nüvo',
};

// Barra de navegación
export const nav = [
  { href: '#servicios', label: 'Servicios' },
  { href: '#edicion', label: 'Edición' },
  { href: '#portafolio', label: 'Videos' },
  { href: '#paquetes', label: 'Paquetes' },
  { href: '#voces', label: 'Voces' },
  { href: '#precios', label: 'Precios' },
  { href: '#nosotros', label: 'Nosotros' },
  { href: '#faq', label: 'Preguntas' },
];

// Ejemplo ilustrativo de la escena de marketing (no son datos reales)
export const review = { initials: '[N]', business: '[Tu negocio]' };

/* ---------- Galería de videos ----------
   Para mostrar tu video: pon el archivo en la carpeta public/videos/ y escribe
   su ruta en src, ej. src: "/videos/mi-video.mp4". Con src: "" se muestra el
   recuadro "[Sube aquí tu video]".
   cat: "motion" | "poligonos" | "camara"   (categorías de los filtros) */
export const videoTabs = [
  { f: 'all', label: 'Todos' },
  { f: 'motion', label: 'Motion graphics' },
  { f: 'poligonos', label: 'Polígonos del Evangelio' },
  { f: 'camara', label: 'A cámara + motion' },
];
export const videos = [
  { title: '[Título del video 1]', sub: 'Puro motion graphics · TikTok', cat: 'motion', src: '' },
  { title: '[Título del video 2]', sub: 'Polígonos del Evangelio · Reels', cat: 'poligonos', src: '' },
  { title: '[Título del video 3]', sub: 'Hablando a cámara · Shorts', cat: 'camara', src: '' },
  { title: '[Título del video 4]', sub: 'Puro motion graphics · Reels', cat: 'motion', src: '' },
  { title: '[Título del video 5]', sub: 'Polígonos del Evangelio · TikTok', cat: 'poligonos', src: '' },
  { title: '[Título del video 6]', sub: 'Hablando a cámara · TikTok', cat: 'camara', src: '' },
];

/* ---------- Voces (archivos en public/audio/voz/) ----------
   Si los archivos no existen, la página muestra la animación muda de siempre. */
export const voices = {
  // Sección "Edición de video": el visitante elige hombre o mujer.
  edicion: [
    { id: 'edicion-hombre', label: 'Hombre' },
    { id: 'edicion-mujer', label: 'Mujer' },
  ],
  // Sección "Voces que regresan": audio original (paso 01) y voz clonada (paso 04).
  voces: {
    original: 'voz-entrada-original',
    clonada: 'voz-salida-clonada',
    // Texto que se escribe en el paso 02. Debe ser el mismo que dice la voz clonada (content/guiones.md, 2b).
    texto: 'Feliz cumpleaños, mi niña. Aunque ya no esté a tu lado, siempre estoy contigo.',
  },
};

/* ---------- Paquetes de edición y contenido ---------- */
export const packages = [
  { title: 'Edición', who: 'Tú grabas, nosotros editamos', amount: '$600', per: 'por video de hasta 60 s',
    items: ['Cortes y ritmo', 'Subtítulos animados', 'Música y efectos', 'Paquete de 8 videos: $4,400 MXN'], cta: 'Cotizar edición' },
  { title: 'Edición + motion', who: 'Tus videos con motion graphics', amount: '$1,200', per: 'por video de hasta 60 s',
    items: ['Todo lo de Edición', 'Motion graphics que animan lo que dices', 'Portada del video', 'Paquete de 8 videos: $8,800 MXN'], cta: 'Cotizar edición' },
  { title: 'Creación de contenido', who: 'Para negocios', amount: '$8,000', per: 'al mes', hl: true, flag: 'El más completo',
    items: ['Análisis de tu negocio y competencia', 'Calendario de 8 videos al mes', 'Guiones y ganchos', 'Edición con motion graphics', 'Textos para publicar', 'Revisión de resultados cada mes'], cta: 'Quiero un plan' },
  { title: 'Marca personal', who: 'Para quien sale a cámara', amount: '$12,000', per: 'al mes',
    items: ['Todo lo de Creación de contenido', '12 videos al mes', 'Dirección de grabación por videollamada', 'Motion graphics avanzados'], cta: 'Quiero un plan' },
];

/* ---------- Precios "desde" ---------- */
export const prices = [
  { title: 'Motion graphics con IA', amount: '$2,500', desc: 'Por video de 30 segundos. Guion, animación y música.',
    items: ['Edición de TikTok, Reels y Shorts', 'Reels y anuncios', 'Explainers', 'Subtítulos'], cta: 'Cotizar video' },
  { title: 'Voces que regresan', amount: '$1,800', desc: 'Mensaje de voz breve. Video homenaje se cotiza aparte.', hl: true, flag: 'Hecho con respeto',
    items: ['Mensaje de voz', 'Audio de recuerdo', 'Consentimiento por escrito'], cta: 'Platicar sin compromiso' },
  { title: 'Página web', amount: '$6,000', desc: 'Landing page para tu negocio, adaptada a celular.',
    items: ['Landing pages', 'Sitios completos', 'Menús digitales'], cta: 'Cotizar página' },
  { title: 'nüvo NFC', amount: '$250', desc: 'Por tarjeta o sticker programado.',
    items: ['Reseñas en Google Maps', 'Paquete de 5 con menú digital: $1,500 MXN'], cta: 'Cotizar tarjetas' },
];

/* ---------- Preguntas frecuentes ---------- */
export const faq = [
  { q: '¿Quién debe autorizar la recreación de una voz?',
    a: 'Los familiares más cercanos o herederos de la persona fallecida. Antes de empezar firmamos con ellos un consentimiento sencillo por escrito. Si hay desacuerdo en la familia o no podemos confirmar la autorización, no realizamos el proyecto.' },
  { q: '¿Qué pasa con los audios que les comparto?',
    a: 'Se usan solo para tu proyecto. No los compartimos con nadie y, después de la entrega, los eliminamos junto con el modelo de voz si así lo solicitas. El resultado final es de la familia.' },
  { q: '¿Qué necesitan para recrear una voz?',
    a: 'Notas de voz, videos o grabaciones donde se escuche claramente a la persona. Entre más limpio el audio, mejor el resultado. Revisamos tu material sin costo y te decimos con honestidad si es suficiente.' },
  { q: '¿Pueden usar la voz para una llamada o para hacerse pasar por alguien?',
    a: 'No. Nunca usamos una voz para suplantar, engañar o cometer fraude, y rechazamos cualquier solicitud de ese tipo. Este servicio existe únicamente como homenaje y recuerdo familiar.' },
  { q: '¿Editan mis videos con IA o a mano?',
    a: 'Las dos cosas, según lo que necesites. La IA nos ayuda a transcribir, limpiar audio o crear elementos; los cortes, el ritmo y las animaciones los decidimos nosotros. Te lo explicamos en la propuesta.' },
  { q: '¿Qué necesito mandar para editar un video?',
    a: 'Tus clips tal como los grabaste (de preferencia en vertical), el audio si lo grabaste aparte, y una idea de lo que quieres decir. Si no sabes por dónde empezar, te ayudamos con el guion.' },
  { q: '¿Cuánto tarda un video o una página web?',
    a: 'Como referencia: un video de 30 segundos, de 5 a 7 días hábiles; una landing page, de 1 a 2 semanas. Te confirmamos la fecha exacta en la propuesta.' },
  { q: '¿Cómo funcionan las tarjetas NFC? ¿Sirven en cualquier teléfono?',
    a: 'Funcionan con la mayoría de los teléfonos iPhone y Android recientes: basta acercar el teléfono, sin instalar aplicaciones. También podemos añadir un código QR como respaldo.' },
  { q: '¿Cómo se paga?',
    a: 'Normalmente 50% de anticipo y 50% contra entrega, por transferencia. [Confirma aquí tus formas de pago y si emites factura].' },
];

/* ---------- Fundadores / perfiles (CV) ----------
   Rol editable: "Motion Design & Video IA" y "Diseño Web & Estrategia Digital"
   son solo sugerencias. Cambien nombre, bio, experiencia, estudios y enlaces.
   cvUrl: "" muestra la nota "(reemplaza con el enlace a tu PDF)".
          Con cvUrl: "/cv/mi-cv.pdf" el botón "Descargar CV" descarga el archivo
          (ponlo en la carpeta public/cv/). */
export const founders = [
  {
    id: 'perfil-1',
    counter: 'P1',
    ini: '[TN]',
    name: '[Tu nombre]',
    role: 'Motion Design & Video IA',          // tarjeta y pie del CV
    roleParts: ['Motion Design', 'Video IA'],   // título del CV: "Motion Design <y> Video IA"
    cofounder: 'Cofundador de nüvo.',
    bio: '[Bio breve, 2 a 3 líneas. Ejemplo: Diseñador de movimiento apasionado por contar historias cortas que se entienden a la primera. Combino animación tradicional con herramientas de inteligencia artificial para producir video de calidad a precios accesibles para negocios locales.]',
    email: 'tucorreo@agencia.com', emailLabel: '[tucorreo@agencia.com]',
    whatsappLabel: '[Tu WhatsApp]',
    linkedin: { url: '#', label: '[Enlace a tu LinkedIn]' },
    portfolio: { url: '#', label: '[Enlace a tu portafolio]' },
    cvUrl: '',
    // Curva de trayectoria (3 etapas). yr / nm / sub son los textos; sub es opcional.
    career: [
      { yr: '[AÑO]', nm: '[Empresa o cliente]', sub: '[Puesto o proyecto freelance]' },
      { yr: '[AÑO]', nm: '[Empresa o cliente]' },
      { yr: '[AÑO] — HOY', nm: 'nüvo' },
    ],
    experience: [
      { when: '[Año] — Actualidad', title: 'Cofundador · Motion Design & Video IA', org: 'nüvo',
        desc: '[Describe lo que haces: dirección de video, animación, recreación de voz con IA, trato con clientes.]' },
      { when: '[Año] — [Año]', title: '[Puesto o proyecto]', org: '[Empresa o cliente]',
        desc: '[Logro o responsabilidad principal, de preferencia con un resultado concreto.]' },
      { when: '[Año] — [Año]', title: '[Puesto o proyecto freelance]', org: '[Empresa o cliente]',
        desc: '[Logro o responsabilidad principal.]' },
    ],
    education: [
      { when: '[Año] — [Año]', title: '[Carrera o licenciatura]', org: '[Universidad o escuela]' },
      { when: '[Año]', title: '[Curso, diplomado o certificación]', org: '[Institución o plataforma]' },
    ],
    skills: ['Motion graphics', 'Edición de video', 'Video generativo con IA', 'Clonación de voz ética', 'Guion para redes', 'Diseño de sonido', '[Otra habilidad]'],
    tools: ['After Effects', 'Premiere Pro', 'Runway', 'ElevenLabs', 'DaVinci Resolve', 'CapCut', 'Figma', '[Otra herramienta]'],
  },
  {
    id: 'perfil-2',
    counter: 'P2',
    ini: '[NN]',
    name: '[Nombre de tu novia]',
    role: 'Diseño Web & Estrategia Digital',
    roleParts: ['Diseño Web', 'Estrategia Digital'],
    cofounder: 'Cofundadora de nüvo.',
    bio: '[Bio breve, 2 a 3 líneas. Ejemplo: Diseñadora web enfocada en que los negocios pequeños se vean profesionales y vendan más. Me encargo de que cada página sea clara, rápida y fácil de encontrar, y de la línea nüvo NFC.]',
    email: 'sucorreo@agencia.com', emailLabel: '[sucorreo@agencia.com]',
    whatsappLabel: '[Su WhatsApp]',
    linkedin: { url: '#', label: '[Enlace a su LinkedIn]' },
    portfolio: { url: '#', label: '[Enlace a su portafolio]' },
    cvUrl: '',
    career: [
      { yr: '[AÑO]', nm: '[Empresa o cliente]', sub: '[Puesto o proyecto freelance]' },
      { yr: '[AÑO]', nm: '[Empresa o cliente]' },
      { yr: '[AÑO] — HOY', nm: 'nüvo' },
    ],
    experience: [
      { when: '[Año] — Actualidad', title: 'Cofundadora · Diseño Web & Estrategia Digital', org: 'nüvo',
        desc: '[Describe lo que haces: diseño de páginas, menús digitales, programación de tarjetas NFC, estrategia de contenido.]' },
      { when: '[Año] — [Año]', title: '[Puesto o proyecto]', org: '[Empresa o cliente]',
        desc: '[Logro o responsabilidad principal, de preferencia con un resultado concreto.]' },
      { when: '[Año] — [Año]', title: '[Puesto o proyecto freelance]', org: '[Empresa o cliente]',
        desc: '[Logro o responsabilidad principal.]' },
    ],
    education: [
      { when: '[Año] — [Año]', title: '[Carrera o licenciatura]', org: '[Universidad o escuela]' },
      { when: '[Año]', title: '[Curso, diplomado o certificación]', org: '[Institución o plataforma]' },
    ],
    skills: ['Diseño web', 'UX / UI', 'Estrategia digital', 'SEO local', 'Google Business Profile', 'Redacción de contenido', 'NFC y menús digitales', '[Otra habilidad]'],
    tools: ['Figma', 'WordPress', 'HTML / CSS', 'Canva', 'Google Analytics', 'Meta Business Suite', 'Notion', '[Otra herramienta]'],
  },
];
